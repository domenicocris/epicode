CREATE TABLE Team (
IDTeam INT,
Nome VARCHAR (20),
Allenatore VARCHAR (20),
EDVinte INT,
CONSTRAINT PK_Team_IDTeam PRIMARY KEY (IDTeam))

CREATE TABLE Turno (
IDTurno INT,
NomeTurno VARCHAR (20),
DataTurno DATE
CONSTRAINT PK_Turno_IDTurno PRIMARY KEY (IDTurno))

CREATE TABLE Partita (
IDPartita INT,
IDTurno INT,
Campo VARCHAR (20),
Ora DATE,
CONSTRAINT PK_Partita_IDTurno_IDPartita PRIMARY KEY (IDPartita),
CONSTRAINT FK_Partita_IDTurno FOREIGN KEY (IDTurno) 
REFERENCES Turno (IDTurno))


CREATE TABLE Giocatore (
IDGiocatore INT,
Nome VARCHAR (25),
Ruolo VARCHAR (25),
Cellulare INT,
IDTeam INT,
CONSTRAINT PK_Giocatore_IDGiocatore PRIMARY KEY (IDGiocatore),
CONSTRAINT FK_Giocatore_IDTeam FOREIGN KEY (IDTeam)
REFERENCES Team (IDTeam))

CREATE TABLE Goal (
IDPartita INT,
Minuto DATE,
IDGiocatore INT,
CalcioPiazzato BIT,
CONSTRAINT PK_Goal_IDPartita_Minuto PRIMARY KEY (IDPartita, Minuto),
CONSTRAINT FK_Goal_IDGiocatore FOREIGN KEY (IDGiocatore)
REFERENCES Giocatore (IDGiocatore),
CONSTRAINT FK_Goal_IDPartita FOREIGN KEY (IDPartita)
REFERENCES Partita (IDPartita))

CREATE TABLE EDVinte (
IDTeam INT,
DataW DATE,
Squadra VARCHAR (20),
CONSTRAINT PK_EDVinte_IDTeam_DataW PRIMARY KEY (IDTeam, DataW),
CONSTRAINT FK_EDVinte_Squadra FOREIGN KEY (IDTeam)
REFERENCES Team (IDTeam))


