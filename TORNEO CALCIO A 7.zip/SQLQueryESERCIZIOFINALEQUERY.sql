SELECT IDGiocatore, Ruolo
FROM Giocatore
WHERE Ruolo = 'Attacco'

SELECT pl.IDGiocatore, pl.Nome
FROM Giocatore pl
INNER JOIN Goal g
ON pl.IDGiocatore = g.IDGiocatore
GROUP BY G.IDPartita

SELECT t.Allenatore, w.DataW, w.Squadra
FROM EDVinte w
INNER JOIN Team t
ON w.IDTeam = t.IDTeam
WHERE t.Allenatore = 'S.Pioli'

SELECT T.Nome, T.Allenatore, w.DataW, t.EDVinte
FROM Team t
LEFT JOIN EDVinte w
ON t.IDTeam = w.IDTeam
GROUP BY t.EDVinte
ORDER BY DESC

SELECT p.IDPartita, g.IDGiocatore, c.Nome, c.Ruolo, c.IDTeam
FROM Partita p
INNER JOIN Goal g
ON p.IDPartita = g.IDPartita
INNER JOIN Giocatore c
ON g.IDGiocatore = c.IDGiocatore

SELECT g.IDGiocatore, g.IDPartita
FROM Goal g 
UNION
SELECT c.Nome, c.Ruolo
FROM Giocatore c

SELECT T.Nome, T.Allenatore
FROM Team t
WHERE t.EDVinte > (
SELECT COUNT(w.IDTeam)
FROM EDVinte w
WHERE w.IDTeam = '100101')

SELECT MIN(g.Minuto)
FROM Goal g
INNER JOIN Partita p
ON g.IDPartita = p.IDPartita
WHERE P.IDPartita > '108'

SELECT DISTINCT p.Campo, g.Minuto
FROM Turno t
LEFT JOIN Partita p
ON t.IDTurno = p.IDTurno
INNER JOIN Goal g
ON p.IDPartita = g.IDPartita
GROUP BY p.Campo, g.Minuto


SELECT Minuto, IDPartita, CalcioPiazzato
FROM Goal
WHERE Minuto > '80'

SELECT t.Nome, t.Allenatore
FROM Team t
WHERE t.IDTeam NOT IN (
SELECT w.IDTeam
FROM EDVinte w)

SELECT t.Nome, t.Allenatore
FROM Team t
WHERE t.IDTeam IN (
SELECT w.IDTeam
FROM EDVinte w)





